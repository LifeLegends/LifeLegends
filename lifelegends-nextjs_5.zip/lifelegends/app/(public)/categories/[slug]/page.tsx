import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { buildMetadata } from '@/lib/seo/metadata';
import { buildBreadcrumbSchema } from '@/lib/seo/jsonld';
import { SiteHeader } from '@/components/layout/SiteHeader';
import { SiteFooter } from '@/components/layout/SiteFooter';
import { CategoryDiscovery } from '@/components/cards/CategoryDiscovery';
import { getAllCategories, getLegendsByCategory } from '@/lib/data/legends';
import { seedCategories } from '@/lib/content/seed-categories';
import styles from './page.module.css';

export function generateStaticParams() {
  return seedCategories.filter((c) => c.hasContent).map((c) => ({ slug: c.slug }));
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const category = seedCategories.find((c) => c.slug === params.slug);
  if (!category) return buildMetadata({ title: 'Category Not Found', path: `/categories/${params.slug}`, noIndex: true });
  return buildMetadata({ title: category.name, description: category.description, path: `/categories/${category.slug}` });
}

export default async function CategoryDetailPage({ params }: { params: { slug: string } }) {
  const category = seedCategories.find((c) => c.slug === params.slug);
  if (!category) notFound();

  const [legends, allCategories] = await Promise.all([
    getLegendsByCategory(category.slug),
    getAllCategories(),
  ]);

  const breadcrumbSchema = buildBreadcrumbSchema([
    { name: 'Home', path: '/' },
    { name: 'Categories', path: '/categories' },
    { name: category.name, path: `/categories/${category.slug}` },
  ]);

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      <SiteHeader activePath="/categories" />
      <main id="main" className={styles.main}>
        <div className={styles.catHero}>
          <div className={styles.catHeroBg} aria-hidden="true" />
          <div className={styles.catHeroContent}>
            <span className={styles.eyebrow}>Category</span>
            <h1 className={styles.title}>{category.name}</h1>
            <p className={styles.desc}>{category.description}</p>
          </div>
        </div>

        <CategoryDiscovery legends={legends} categories={allCategories} categoryHasContent={category.hasContent} />
      </main>
      <SiteFooter />
    </>
  );
}
