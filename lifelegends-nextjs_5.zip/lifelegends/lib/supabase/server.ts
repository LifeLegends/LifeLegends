/**
 * Server-side Supabase client for Server Components, Route Handlers, and
 * Server Actions. Uses the anon key + cookie-based session by default;
 * the service-role key (server-only, never exposed to the client) is
 * reserved for admin write paths behind auth — see SDD §7.7 Security.
 */
import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';
import type { Database } from './types';

export function createClient() {
  const cookieStore = cookies();

  return createServerClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL ?? '',
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? '',
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options),
            );
          } catch {
            // Called from a Server Component with no response to write to —
            // safe to ignore when middleware handles session refresh.
          }
        },
      },
    },
  );
}
